package com.accenture.withoutxml;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanGenerator {

	@Bean
	public SampleProgram2 getMyBeanObject() {
		return new SampleProgram2();
	}
}
