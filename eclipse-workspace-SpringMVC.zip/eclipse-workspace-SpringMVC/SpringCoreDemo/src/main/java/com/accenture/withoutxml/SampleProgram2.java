package com.accenture.withoutxml;

public class SampleProgram2 {

	public void displayMe() {
		System.out.println("Ganesh......Welcome");
	}
}
