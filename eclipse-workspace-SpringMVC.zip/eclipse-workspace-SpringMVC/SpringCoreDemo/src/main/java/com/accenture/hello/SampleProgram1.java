package com.accenture.hello;

public class SampleProgram1 {

	public void show() {
		System.out.println("Hello Ganesh");
	}
}
