package com.accenture.withoutxml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestMe {

	public static void main(String[] args) {
		ApplicationContext obj =  new AnnotationConfigApplicationContext(BeanGenerator.class);
		SampleProgram2 ob =obj.getBean(SampleProgram2.class);
		ob.displayMe();
	}

}
