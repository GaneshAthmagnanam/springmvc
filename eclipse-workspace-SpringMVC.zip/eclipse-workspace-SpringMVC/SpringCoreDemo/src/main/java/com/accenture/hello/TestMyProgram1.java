package com.accenture.hello;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMyProgram1 {

	public static void main(String[] args) {
		ApplicationContext obj = new ClassPathXmlApplicationContext("XMLSampleProgram1.xml");
		// SampleProgram1 myObj= obj.getBean("one",SampleProgram1.class);
		// myObj.show();
		BookStore result = obj.getBean("three", BookStore.class);
		result.display();
	}

}
