package com.accenture.loginmvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	
	@Autowired
	private LoginBean loginBean;
	
	public LoginBean getLoginBean() {
		return loginBean;
	}

	public void setLoginBean(LoginBean loginBean) {
		this.loginBean = loginBean;
	}

	@RequestMapping("/Signin")
	public ModelAndView letMeGo(@RequestParam("uname") String userName,@RequestParam("pwd") String pwd) {
		ModelAndView mv= new ModelAndView();
		boolean result = loginBean.isAuthentic(userName, pwd);
		if(result) {
			mv.addObject("Message", "Welcome"+userName);
			mv.setViewName("Success");
		}
		else {
			mv.addObject("Message", "Failed");
			mv.setViewName("Fail");
		}
		return mv;
		
	}

}
