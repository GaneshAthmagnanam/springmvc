package com.accenture.formhandling;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {
	@Autowired
	private User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	@ModelAttribute("Headermessage")
	public String header() {
		
		return "NIT";
	}

	@RequestMapping("/loginpage")
	public ModelAndView showLoginPage() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("mybean", user);
		//mv.addObject("Headermessage", "NIT");
		mv.setViewName("UserLogin");
		return mv;
	}

	@RequestMapping(value = "/userprofile", method = RequestMethod.POST)
	public ModelAndView showUserProfile(@ModelAttribute("mybean") @Valid User user,BindingResult result) {
		// user.setFirstName(firstName);<!--look, setter is disabled corresponding setter method will be called becoz of modelattribute -->
		// user.setLastName(lastName);
		ModelAndView mv = null;
		if(result.hasErrors()) {
			mv=new ModelAndView("loginpage");
		}
		else {
			mv=new ModelAndView();
			mv.addObject("getBean", user);
			//mv.addObject("Headermessage", "NIT");
			mv.setViewName("profilePage");
			
		}
		return mv;

	}
}
