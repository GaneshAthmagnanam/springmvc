package com.accenture.loginmvc;

import org.springframework.stereotype.Component;

@Component
public class LoginBean {

	public boolean isAuthentic(String userName, String password) {
		if(userName.equalsIgnoreCase("Ganesh") && password.equalsIgnoreCase("Ganesh")) 
			return true;
		else
		return false;
	}
}
