package com.accenture.student;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class StudentController {
	
	@Autowired
	private Student student;
	

	public Student getStudent() {
		return student;
	}


	public void setStudent(Student student) {
		this.student = student;
	}

	@ModelAttribute("subjectList")
	public List<String> subjects(){
		List<String> obj= new ArrayList<String>();
		obj.add("");
		obj.add("maths");
		obj.add("phy");
		return obj;
		
	}

	@RequestMapping("/admission")
	public ModelAndView admission() {
		ModelAndView obj = new ModelAndView();
		obj.addObject("studentBean", student);
		obj.setViewName("admissionPage");
		return obj;
	}
	@RequestMapping("/studentdetails")
	public ModelAndView studentDetails(@ModelAttribute ("studentBean") @Valid Student student,BindingResult result) {
		
		ModelAndView obj = null;
		System.out.println(result);
		if(result.getErrorCount()>0) {
			obj=new ModelAndView("admissionPage");
		}
		else {
			obj=new ModelAndView();
			obj.addObject("detailsBean", student);
			obj.setViewName("details");
		}
		
		return obj;
	}
}
