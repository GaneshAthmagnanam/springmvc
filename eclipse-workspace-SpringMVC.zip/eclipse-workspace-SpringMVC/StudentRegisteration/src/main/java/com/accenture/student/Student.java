package com.accenture.student;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Component	
public class Student {

	@NotEmpty(message="kindly provide firstname")
	private String firstName;
	@NotEmpty(message="kindly provide lastname")
	private String lastName;
	@NotEmpty(message="kindly provide subject")
	private String subject;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
}
